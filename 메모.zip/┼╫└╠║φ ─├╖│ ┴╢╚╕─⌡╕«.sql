select 
	mst.table_physics_nm
	, logic.table_logic_nm
	, mst.ord
	, mst.column_physics_name
	, logic.column_logic_name
	, mst.data_type
	, case 
		when pk.pk_yn is not null then 'Y'
	else 'N' end as pk_yn
	, mst.not_null as not_null_yn
	, case 
		when position('enc' in  mst.column_physics_name) > 0 then 'Y' 
		else 'N' 
	end as enc_yn
	, col_def
	, mst.col_cd_yn
from 
	(
		SELECT 
			TABLE_NAME as table_physics_nm
			, column_name as column_physics_name
			, case 
				when is_nullable = 'YES' then 'N'
				else 'Y' 
			end as not_null
			, case 
				when data_type = 'character' then 'bpchar('||character_maximum_length||')'
				when data_type = 'character varying' then 'varchar('||character_maximum_length||')'
				when data_type = 'numeric' then 
					case when numeric_scale <> 0 then 'numeric('||numeric_precision||','||numeric_scale||')'
					else 'numeric('||numeric_precision||')'
					end 
				when data_type = 'timestamp without time zone' then 'timestamp'
				end as data_type
			, dtd_identifier as ord
			, ORDINAL_POSITION as posi
			, column_default as col_def
			, (case when col.column_name = cccm.comm_cd then 'Y' else 'N' end) as col_cd_yn
		FROM 
			INFORMATION_SCHEMA.columns col
			left outer join co_comm_cd_m cccm on col.column_name = cccm.comm_cd
		WHERE 
			1=1 
			and TABLE_CATALOG = 'UCMPDB31DEV'
			and table_schema = 'ucmown'
			and TABLE_NAME = 'lk_sinhan_chrg_aply_p'
			--and column_name = 'rclt_stcd'
	) mst
inner join 
	(
	select 
		table_physics_nm
		, table_logic_nm
		, column_physics_name
		, column_logic_name
	from 
	(
	SELECT
		PS.RELNAME AS table_physics_nm,
		PA.ATTNAME AS column_physics_name,
		PD.DESCRIPTION AS column_logic_name
	FROM PG_STAT_ALL_TABLES PS, PG_DESCRIPTION PD, PG_ATTRIBUTE PA
	WHERE 
		1=1
		and PD.OBJSUBID<>0
		AND PS.RELID=PD.OBJOID
		AND PD.OBJOID=PA.ATTRELID
		AND PD.OBJSUBID=PA.ATTNUM
	) tabo
inner join 
	(
		SELECT 
			N.nspname
			, C.relname 
			, OBJ_DESCRIPTION(C.OID) as table_logic_nm
		FROM PG_CATALOG.PG_CLASS C 
		INNER JOIN PG_CATALOG.PG_NAMESPACE N 
			ON C.RELNAMESPACE=N.OID 
		WHERE C.RELKIND = 'r'
		) tb
		on tabo.table_physics_nm = tb.relname	
	) logic
	on logic.table_physics_nm = mst.table_physics_nm
	and logic.column_physics_name = mst.column_physics_name
left outer join 
	(
	SELECT 
		table_name
		, column_name
		, constraint_name as pk_yn
	FROM 
		INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE 
	WHERE 
		1=1
		and table_catalog	= 'UCMPDB31DEV'
		and table_schema	= 'ucmown'
	) pk 
	on pk.table_name	= mst.table_physics_nm
	and pk.column_name = mst.column_physics_name
where 
	1=1
order by mst.table_physics_nm, mst.posi, mst.ord
;
